namespace Org.BouncyCastle.OpenPgp
{
	public abstract class PgpObject
	{
		internal PgpObject()
		{
		}
	}
}
