namespace Org.BouncyCastle.OpenPgp
{
	public interface IStreamGenerator
	{
		void Close();
	}
}
