﻿using System;

namespace Org.BouncyCastle.Tls
{
    public abstract class ChangeCipherSpec
    {
        public const short change_cipher_spec = 1;
    }
}
