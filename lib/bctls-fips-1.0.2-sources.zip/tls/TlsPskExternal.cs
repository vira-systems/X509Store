﻿using System;

namespace Org.BouncyCastle.Tls
{
    public interface TlsPskExternal
        : TlsPsk
    {
    }
}
