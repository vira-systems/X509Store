using System;

namespace Org.BouncyCastle.Asn1.X509
{
	public class X509Attributes
	{
		public static readonly DerObjectIdentifier RoleSyntax = new DerObjectIdentifier("2.5.4.72");
	}
}
