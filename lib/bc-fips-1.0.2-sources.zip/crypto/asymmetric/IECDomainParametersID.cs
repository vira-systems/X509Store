﻿using System;

namespace Org.BouncyCastle.Crypto.Asymmetric
{
	public interface IECDomainParametersID
	{
		string CurveName {
			get;
		}
	}
}

