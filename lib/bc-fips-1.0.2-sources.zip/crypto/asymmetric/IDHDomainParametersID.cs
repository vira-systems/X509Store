﻿using System;

namespace Org.BouncyCastle.Crypto.Asymmetric
{
	public interface IDHDomainParametersID
	{
		string ParametersName {
			get;
		}
	}
}

