using System;

namespace Org.BouncyCastle.Ocsp
{
	public abstract class CertificateStatus
	{
		public static readonly CertificateStatus Good = null;
	}
}
