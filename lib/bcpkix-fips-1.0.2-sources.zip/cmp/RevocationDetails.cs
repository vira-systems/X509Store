﻿using Org.BouncyCastle.Asn1.Cmp;
using Org.BouncyCastle.Asn1.X500;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Math;

namespace Org.BouncyCastle.Cmp
{
    public class RevocationDetails
    {
        private RevDetails revDetails;

        public RevocationDetails(RevDetails revDetails)
        {
            this.revDetails = revDetails;
        }

        public X500Name Subject
        {
            get { return revDetails.CertDetails.Subject; }
        }

        public X500Name Issuer
        {
            get { return revDetails.CertDetails.Issuer; }
        }

        public BigInteger SerialNumber
        {
            get
            {
                return revDetails.CertDetails.SerialNumber.Value; //   getCertDetails().getSerialNumber().getValue();
            }
        }

        public RevDetails ToASN1Structure()
        {
            return revDetails;
        }
    }
}